import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";


import Login from "./components/login_component";
import SignUp from "./components/signup_component";
import Home from "./components/Home";
import AboutUs from "./components/AboutUs";
import Course from "./components/Course";
import Certificate from "./components/myCertificates";

function App() {
  return (
    <Router>
          
            <Routes>
              <Route exact path="/" element={<Login />} />
              <Route path="/sign-in" element={<Login />} />
              <Route path="/sign-up" element={<SignUp />} />
              <Route path="/userDetails" element={<Home />} />
              <Route path="/aboutus" element={<AboutUs />}/> 
              <Route path="/courses" element={<Course />}/> 
              <Route path="/certificates" element={<Certificate />}/> 
      
              
            </Routes>
           
  
    </Router>
  );
}

export default App;
