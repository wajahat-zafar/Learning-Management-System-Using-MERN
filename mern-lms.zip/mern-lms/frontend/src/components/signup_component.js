import React, { Component } from "react";
import Logo from './images/Logo2.jpg'; 
export default class SignUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fname: "",
      lname: "",
      email: "",
      password: "",
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(e) {
    e.preventDefault();
    const { fname, lname, email, password } = this.state;
    if (fname && lname && email && password){
      console.log(fname, lname, email, password);
    
    
    fetch("http://localhost:5000/register", {
      method: "POST",
      crossDomain: true,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        fname,
        email,
        lname,
        password,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data, "userRegister");
        if (data.status =='OK'){
          alert("Register successful")

        }else{
          alert("User Already Exists")
        }
        
      });

    }else{
        alert("Please enter the details!")
    
    }
      
        
  }
  render() {
    return (
      <div className="App">
        <div className="auth-wrapper">
          <div className="auth-inner"> 
      
      <form onSubmit={this.handleSubmit}>
        <img  src={Logo} style={{width: 100, height: 100, borderRadius: 400/ 2,position:'relative',
      left:'120px'}}  />

        <h3 style={{ color: 'green' }}>Sign Up</h3>

        <div className="mb-3">
          <label  style={{ color: 'black' }}>First name</label>
          <input
            type="text"
            className="form-control"
            placeholder="First name"
            onChange={(e) => this.setState({ fname: e.target.value })}
          />
        </div>

        <div className="mb-3">
          <label style={{ color: 'black' }} >Last name</label>
          <input
            type="text"
            className="form-control"
            placeholder="Last name"
            onChange={(e) => this.setState({ lname: e.target.value })}
          />
        </div>

        <div className="mb-3">
          <label style={{ color: 'black' }} >Email address</label>
          <input
            type="email"
            className="form-control"
            placeholder="Enter email"
            onChange={(e) => this.setState({ email: e.target.value })}
          />
        </div>

        <div className="mb-3">
          <label style={{ color: 'black' }} >Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter password"
            onChange={(e) => this.setState({ password: e.target.value })}
          />
        </div>

        
          <button  type="submit" className="btn btn-success">
           <span>Register </span> 
          </button>
      
        <p style={{ color: 'black' }} className="forgot-password text-right">
          Already registered <a  style={{ color: 'green' }} href="/sign-in">sign in?</a>
        </p>
      </form>
      </div>
        </div>
      </div> 
    );
  }
}
