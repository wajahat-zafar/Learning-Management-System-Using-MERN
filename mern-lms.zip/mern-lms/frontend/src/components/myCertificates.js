import React from "react";
import './myCertificates.css'
import certificateM from './images/certificatemaths.png';
import certificateP from './images/certificateP.jpg';
import certificateC from './images/certificateC.png';
import certificateB from './images/certificateB.png';
import {NavLink} from "react-router-dom"
import Logo from './images/Logo2.jpg';
const Certificate =()=>{
    return(
        <>
         <div className="container-fluid nav-bg">
            <div className="row">
                <div className="col-20 mx-auto">

               
        <nav className="navbar navbar-expand-lg navbar-light ">
        <img  src={Logo} style={{width: 120, height: 100, borderRadius: 400/ 2,position:'relative',
      left:'60px'}}  />
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNav">
    <ul className="navbar-nav ml-auto ">
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/userDetails">Home </NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/aboutus">AboutUs</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/courses">Courses</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/certificates">My Certificates</NavLink>
      </li>
     
      
    </ul>
  </div>
</nav>
</div>

</div>

</div>

    <div id="cards_landscape_wrap-2">
        <div className="container">
        <div class="thirteen">
  <h1>My Certificates</h1>
</div>
<div class="wrap">
  
</div>
        
            <div className="row">
                <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    
                    <a href="">
                        <div className="card-flyer">
                            <div className="text-box">
                                <div className="image-box">
                                   
                                    <img src={certificateM} alt="" />
                                </div>
                                
                                <div className="text-container">
                                <h6>Mathematics</h6>
                                    <p>Mathematics is an area of knowledge that includes the topics of numbers, formulas and related structures, shapes and the spaces in which they are contained.</p>
                                    <button type="button" className="btn btn-outline-success">Get Now!</button>
                                </div>


                                
                            </div>
                        </div>
                    </a>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div className="card-flyer">
                            <div className="text-box">
                                <div className="image-box">
                                    <img src={certificateP}alt="" />
                                </div>
                                <div className="text-container">                                    
                                    <h6>Physics</h6>
                                    <p>Physics is the natural science that studies matter, its fundamental constituents, its motion and behavior through space and time and motion.It is the best way to study science</p>
                                    <button type="button" className="btn btn-outline-success">Get Now!</button>                                
                                </div>

                            </div>
                        </div>
                    </a>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div className="card-flyer">
                            <div className="text-box">
                                <div className="image-box">
                                    <img src={certificateC} alt="" />
                                </div>

                                <div className="text-container">
                                    <h6>Chemistry</h6>
                                   <p>Chemistry is the scientific study of the properties and behavior of matter. It is a natural science that covers the elements,atoms and compounds and their volumes.</p>
                                   <button type="button" className="btn btn-outline-success">Get Now!</button>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div className="card-flyer">
                            <div className="text-box">
                                <div className="image-box">
                                    <img src={certificateB} alt="" />
                                </div>
                                <div className="text-container">
                                    <h6>BioLogy</h6>
                                   <p>Biology is the scientific study of life. It is a natural science with a broad scope but has several unifying themes that tie it together as a single, coherent field.</p>
                                   <button type="button" className="btn btn-outline-success">Get Now!</button>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    </>
    )
}

export default Certificate;