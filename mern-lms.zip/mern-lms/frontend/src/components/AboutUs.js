import React from "react";
import './AboutUs.css'
import LMS from './images/lms.png'
import Logo from './images/Logo2.jpg';
import {NavLink} from "react-router-dom";

const AboutUs =()=>{
    return(
        <>
        <div className="container-fluid nav-bg">
            <div className="row">
                <div className="col-20 mx-auto">

               
        <nav className="navbar navbar-expand-lg navbar-light ">
        <img  src={Logo} style={{width: 120, height: 100, borderRadius: 400/ 2,position:'relative',
      left:'60px'}}  />
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNav">
    <ul className="navbar-nav ml-auto ">
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/userDetails">Home </NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/aboutus">AboutUs</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/courses">Courses</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/certificates">My Certificates</NavLink>
      </li>
     
      
    </ul>
  </div>
</nav>
</div>

</div>

</div>
        <section class="about-section">
        <div class="container">
            <div class="row">                
                <div class="content-column col-lg-6 col-md-12 col-sm-12 order-2">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="title">About Our LMS</span>
                            <h2>We are Enthusiastly working since 2022 for betterment of students</h2>
                        </div>
                        <div style={{color:'green'}} class="text"> Typically, a learning management system provides an instructor with a way to create and deliver content, monitor student participation and assess student performance. A learning management system may also provide students with the ability to use interactive features such as threaded discussions, video conferencing and discussion forums.</div>
                      <div  style={{color:'green'}} class="text">
                        We are here to serve you next level tutorial that currently in trend to match you with your expertise. where you can find many good quality content related to web development and tutorials about plugins. here we are using html, html5, css, css3, jquery & javascript along with inspirational UI design layout by professionals.
                      </div>
                        <div class="btn-box">
                            <a href="#" class="theme-btn btn-style-one">Contact Us</a>
                        </div>
                    </div>
                </div>

                
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft">
                      <div class="author-desc">
                        <h2>Learning Management System</h2>
                        <span>By Muhammad Wajahat</span>
                      </div>
                        <figure class="image-1"><a href="#" class="lightbox-image" data-fancybox="images"><img  src={LMS}/></a></figure>
                     
                    </div>
                </div>
              
            </div>
           <div class="sec-title">
                            <span class="title">Our Future Goal</span>
                            <h2>We want to educate the students by our technical courses</h2>
                        </div>
          <div style={{color:'green' }} class="text">
          The purpose is to empower Learning and Development (L&D) departments with training and development for their learners, so they can continue a company's growth, success, and ultimately drive revenue. These are some pretty big learning goals.
              </div>
               <div style={{color:'green'}} class="text">
               Most LMSs are web based and are used in various educational institutes and companies to improve classroom teaching, learning methodology, and company records. They are used in various industries and scenarios like in financial services, compliance training, computer based training, online assessment, collaborative learning, application sharing, and so on.
              </div>
               <div style={{color:'green'}} class="text">                
               Some LMSs also include a performance management system which encompasses employee appraisal, competency management, and skill gap analysis.
              </div>
               <div style={{color:'green'}} class="text">
                Lets get start learning from today!
              </div>
              
            
        </div>
        
    </section>
    
    
    
    </>
    
    )
}

export default AboutUs;