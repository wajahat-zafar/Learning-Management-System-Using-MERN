import React, { Component } from "react";
import Logo from './images/Logo2.jpg'; 
export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleSubmit(e) {
    e.preventDefault();
    const { email, password } = this.state;
    if (email && password){
      console.log(email, password);
    fetch("http://localhost:5000/login-user", {
      method: "POST",
      crossDomain: true,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        email,
        password,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data, "userRegister");
        if (data.status == "ok") {
          alert("login successful");
          window.localStorage.setItem("token", data.data);
          window.location.href = "./userDetails";
        }else{
          alert("Please enter the correct credentials!")
        }
      });

    }else{
      alert("Please Enter the credentials!")
    }
    
  }
  render() {
    return (
      <div className="App">
        <div className="auth-wrapper">
          <div className="auth-inner"> 
     
      <form className="Form"  onSubmit={this.handleSubmit}>
        <img  src={Logo} style={{width: 100, height: 100, borderRadius: 400/ 2,position:'relative',
      left:'120px'}}  />
        <h3 style={{ color: 'green' }} >Sign In</h3>

        <div className="mb-3">
          <label style={{ color: 'black' }}>Email address</label>
          <input
            type="email"
            className="form-control"
            placeholder="Enter email"
            onChange={(e) => this.setState({ email: e.target.value })}
          />
        </div>

        <div className="mb-3">
          <label style={{ color: 'black' }}>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter password"
            onChange={(e) => this.setState({ password: e.target.value })}
          />
        </div>

        <div className="mb-3">
          <div className="custom-control custom-checkbox">
            <input
              type="checkbox"
              className="custom-control-input"
              id="customCheck1"
            />
            <label className="custom-control-label" htmlFor="customCheck1">
              Remember me
            </label>
          </div>
        </div>

        
          <button   type="submit"  className="btn btn-success">
            <span>login</span>
          </button> 
        
        <p className="forgot-password text-right">
          <a style={{ color: 'green' }} href="/sign-up">Sign Up</a>
        </p>
      </form>

       </div>
        </div>
      </div> 
    );
  }
}
