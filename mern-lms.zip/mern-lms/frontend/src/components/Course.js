import React from "react";
import './Course.css';
import maths from './images/maths.jpg';
import physics from './images/physics.jpg';
import chemistry from './images/chemistry.jpg';
import biology from './images/bio.png';

import Logo from './images/Logo2.jpg';
import {NavLink} from "react-router-dom";


const Course =()=>{
    return(
        <>
        <div className="container-fluid nav-bg">
            <div className="row">
                <div className="col-20 mx-auto">

               
        <nav className="navbar navbar-expand-lg navbar-light ">
        <img  src={Logo} style={{width: 120, height: 100, borderRadius: 400/ 2,position:'relative',
      left:'60px'}}  />
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNav">
    <ul className="navbar-nav ml-auto ">
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/userDetails">Home </NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/aboutus">AboutUs</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/courses">Courses</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/certificates">My Certificates</NavLink>
      </li>
     
      
    </ul>
  </div>
</nav>
</div>

</div>

</div>
        
<div id="cards_landscape_wrap-2">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                   
                                    <img src={maths} alt="" />
                                </div>
                                
                                <div class="text-container">
                                <h6>Mathematics</h6>
                                    <p>Mathematics is an area of knowledge that includes the topics of numbers, formulas and related structures, shapes and the spaces in which they are contained.</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src={physics}alt="" />
                                </div>
                                <div class="text-container">                                    
                                    <h6>Physics</h6>
                                    <p>Physics is the natural science that studies matter, its fundamental constituents, its motion and behavior through space and time, and the related entities of energy and force.</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src={chemistry} alt="" />
                                </div>

                                <div class="text-container">
                                    <h6>Chemistry</h6>
                                   <p>Chemistry is the scientific study of the properties and behavior of matter. It is a natural science that covers the elements,atoms and compounds and their volumes.</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="">
                        <div class="card-flyer">
                            <div class="text-box">
                                <div class="image-box">
                                    <img src={biology} alt="" />
                                </div>
                                <div class="text-container">
                                    <h6>BioLogy</h6>
                                   <p>Biology is the scientific study of life. It is a natural science with a broad scope but has several unifying themes that tie it together as a single, coherent field.</p>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <section>
    
        
  <div class="container-fluid">
    
    
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <div class="card card_red text-center">
            
            <div class="title">
                
              <i className="fa fa-paper-plane" aria-hidden="true"></i>
              <h2>Mathematics</h2>
            </div>
            <div className="price">
              <h4><sup>$</sup>10</h4>
            </div>
            <div className="option">
            <h2>Modules</h2>
              <ul>
                <li><i className="fa fa-check" aria-hidden="true"></i>Arithematics</li>
                <li><i className="fa fa-check" aria-hidden="true"></i>Algebra</li>
                <li><i className="fa fa-check" aria-hidden="true"></i>Geometry</li>
                <li><i className="fa fa-times" aria-hidden="true"></i>Trignometry</li>
                </ul>
            </div>
            <a href="#">Get Now</a>
          </div>
        </div>
        <div className="col-sm-4">
          <div className="card card_violet text-center">
            <div className="title">
              <i className="fa fa-plane" aria-hidden="true"></i>
              <h2>Physics</h2>
            </div>
            <div className="price">
              <h4><sup>$</sup>10</h4>
            </div>
            <div className="option">
            <h2>Modules</h2>
              <ul>
                <li><i className="fa fa-check" aria-hidden="true"></i>Mechanics </li>
                <li><i className="fa fa-check" aria-hidden="true"></i>Dynamics</li>
                <li><i className="fa fa-check" aria-hidden="true"></i>Light</li>
                <li><i className="fa fa-times" aria-hidden="true"></i>Electricity</li>
                </ul>
            </div>
            <a href="#">Get Now</a>
          </div>
        </div>
        <div className="col-sm-4">
          <div className="card card_three text-center">
            <div className="title">
              <i className="fa fa-rocket" aria-hidden="true"></i>
              <h2>Chemistry</h2>
            </div>
            <div className="price">
              <h4><sup>$</sup>10</h4>
            </div>
            <div className="option">
            <h2>Modules</h2>
              <ul>
                <li><i className="fa fa-check" aria-hidden="true"></i>Basic Chemistry</li>
                <li><i className="fa fa-check" aria-hidden="true"></i>InOrganic</li>
                <li><i className="fa fa-check" aria-hidden="true"></i>Organic</li>
                <li><i className="fa fa-times" aria-hidden="true"></i>Industrial Chemistry</li>
                </ul>
            </div>
            <a href="#">Get Now</a>
          </div>
        </div>
        
      </div>
    </div>
  </div>
  
</section>

    
  

    
    
  
        </>
    )
}

export default Course;