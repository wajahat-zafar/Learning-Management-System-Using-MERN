

import React, { Component } from "react";
import './Home.css'
import Pic from './images/pic.jpg';
import Certificate from './images/certificate.png';
import {NavLink} from "react-router-dom"
import Logo from './images/Logo2.jpg';

export default class UserDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userData: "",
    };
  }
  componentDidMount() {
    fetch("http://localhost:5000/userData", {
      method: "POST",
      crossDomain: true,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        token: window.localStorage.getItem("token"),
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        console.log(data, "userData");
        this.setState({ userData: data.data });
      });
  }
  render() {
    return (
      <>
      <div className="container-fluid nav-bg">
            <div className="row">
                <div className="col-20 mx-auto">

               
        <nav className="navbar navbar-expand-lg navbar-light ">
        <img  src={Logo} style={{width: 120, height: 100, borderRadius: 400/ 2,position:'relative',
      left:'60px'}}  />
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarNav">
    <ul className="navbar-nav ml-auto ">
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/userDetails">Home </NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/aboutus">AboutUs</NavLink>
      </li>
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/courses">Courses</NavLink>
      </li>
    
      <li className="nav-item active">
        <NavLink   className="nav-link" to="/certificates">My Certificates</NavLink>
      </li>
     
      
    </ul>
  </div>
</nav>
</div>

</div>

</div>
      <section id="header" className="d-flex align-items-centre">
      
                    
        <div  className="container-fluid nav_bg"> 
          <div className="row"> 
            <div className="col-20 mx-auto">
              <div className="row">
              <div className="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex justify-content-center flex-column">
                <h1 className="head1">
                  Lets Start Learning with our <strong className="strong">"Learning Management System"</strong>
                </h1>
                <h2 className="my-3">
                  We have a team of talented instuctors!
                </h2>
                
                <div className="btn1">
               <NavLink to='/courses'><button type="button" class="btn btn-outline-success">Gets Started</button></NavLink> 
                 
                 
                </div>
                 
            </div>
              <div className="col-lg-6 order-1 order-lg-2 header-img">
              <img className="image" src={Pic  } style={{width: 500, height: 500, borderRadius: 10, position: "relative",
            top:50 }}/>

              </div>
              </div>
              

            </div>
            <div></div>
            <img  src={Certificate} class="img-fluid" alt="..."></img>
            
            
            <div className="footer">
            <div class="col">

            <h1>Company</h1>
            <ul>
            <li>About</li>
            <li>Mission</li>
            <li>Services</li>
            <li>Social</li>
            <li>Get in touch</li>
            </ul>
            </div>
            <div class="col">
            <h1>Products</h1>
            <ul>
            <li>About</li>
            <li>Mission</li>
            <li>Services</li>
            <li>Social</li>
            <li>Get in touch</li>
          </ul>
          </div>
          <div class="col">
          <h1>Accounts</h1>
          <ul>
          <li>About</li>
          <li>Mission</li>
          <li>Services</li>
          <li>Social</li>
          <li>Get in touch</li>
          </ul>
        </div>
        <div class="col">
    <h1>Resources</h1>
    <ul>
      <li>Webmail</li>
      <li>Redeem code</li>
      <li>WHOIS lookup</li>
      <li>Site map</li>
      <li>Web templates</li>
      <li>Email templates</li>
    </ul>
  </div>
  <div class="col">
    <h1>Support</h1>
    <ul>
      <li>Contact us</li>
      <li>Web chat</li>
      <li>Open ticket</li>
    </ul>
  </div>
  <div class="col social">
    <h1>Social</h1>
    <ul>
      <li>Facebook</li>
      <li>Whatsapp</li>
      <li>Instagram</li>
      <li>Twitter</li>
    </ul>
  </div>


            </div>
            

          </div>
        </div>

      </section>
      </>
    );
  }
}
